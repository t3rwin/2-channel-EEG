/*
 * CSV.h
 *
 *  Created on: Apr 22, 2024
 *      Author: sebtu
 */

#ifndef INC_CSV_H_
#define INC_CSV_H_

int count_csv_rows(const char *filename);


#endif /* INC_CSV_H_ */
