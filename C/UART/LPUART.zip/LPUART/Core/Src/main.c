/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "QUEUE.h"
#include "CSV.h"

UART_HandleTypeDef hlpuart1;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_LPUART1_UART_Init(void);

//initalizations used for UART transmission and receiving.
uint8_t tx_buffer[4] = {0x12, 0x54, 0x6C, 0xAA};
uint8_t rx_data[1];
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_LPUART1_UART_Init();

  //test to see if the data parsing will work
  //data will be replaced by data from the ADC

  const char *filename = "1open-4reading-300.csv";  // Name of the CSV file
  int rows = count_csv_rows(filename);
  if (rows != -1) {
      printf("The file '%s' has %d rows.\n", filename, rows);
  }
  uint32_t data = 0x6543AB;
  parseADC(data, tx_buffer);


  Queue q;
  initQueue(&q);

  enqueue(&q, 0xFFF);
  enqueue(&q, 0xFFE);
  enqueue(&q, 0xFFD);
  enqueue(&q, 0xFFC);
  enqueue(&q, 0xFFB);
  enqueue(&q, 0xFFA);


  //transmit and receive
  while (1)
  {
	  if(!(isEmpty(&q))){
		  parseADC(peek(&q), tx_buffer);
		  HAL_UART_Transmit(&hlpuart1, tx_buffer, 4, 20);
		  dequeue(&q);
	  }else{
		  enqueue(&q, 0xFFF);
		  enqueue(&q, 0xFFE);
		  enqueue(&q, 0xFFD);
		  enqueue(&q, 0xFFC);
		  enqueue(&q, 0xFFB);
		  enqueue(&q, 0xFFA);
	  }
	  HAL_UART_Receive_IT(&hlpuart1, rx_data, 1);
	  HAL_Delay(250);
  }
}


  //just transmit
  /*uint8_t tx_buffer[4] = {0x02,0xFA,0xFB,0xFC};
  //uint8_t tx_buffer[3] = "HEL";

  while (1)
  {
	  HAL_UART_Transmit(&hlpuart1, tx_buffer, 4, 20);
	  HAL_Delay(500);
  }
}*/

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief LPUART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_LPUART1_UART_Init(void)
{
  hlpuart1.Instance = LPUART1;
  hlpuart1.Init.BaudRate = 209700;
  hlpuart1.Init.WordLength = UART_WORDLENGTH_8B;
  hlpuart1.Init.StopBits = UART_STOPBITS_1;
  hlpuart1.Init.Parity = UART_PARITY_NONE;
  hlpuart1.Init.Mode = UART_MODE_TX_RX;
  hlpuart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  hlpuart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  hlpuart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&hlpuart1) != HAL_OK)
  {
    Error_Handler();
  }

}

static void MX_GPIO_Init(void)
{
  __HAL_RCC_GPIOG_CLK_ENABLE();
  HAL_PWREx_EnableVddIO2();

}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(huart);

  tx_buffer[0] = rx_data[0];
}

void parseADC(uint32_t data, uint8_t bytes[4]) {
    // Ensure data is within 24-bit range
    data &= 0xFFFFFF;

    // Extract each byte
    bytes[0] = (data >> 16) & 0xFF; // Most significant byte
    bytes[1] = (data >> 8) & 0xFF;  // Middle byte
    bytes[2] = data & 0xFF;         // Least significant byte
}

void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
