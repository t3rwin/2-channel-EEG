#include <stdio.h>

#include "CSV.h"

int count_csv_rows(const char *filename) {
    FILE *file = fopen(filename, "r");  // Open the CSV file for reading
    if (file == NULL) {
        perror("Error opening file");   // Print an error message if file can't be opened
        return -1;                      // Return -1 on file error
    }

    int count = 0;
    char buffer[1024];  // Buffer to store line contents

    while (fgets(buffer, sizeof(buffer), file)) {
        count++;        // Increment count for each line read
    }

    fclose(file);       // Close the file
    return count;       // Return the count of rows
}
